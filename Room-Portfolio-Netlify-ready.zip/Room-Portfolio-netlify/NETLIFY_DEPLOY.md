# Déploiement Netlify

Ce projet est un projet Next.js avec App Router, Route Handlers et MongoDB. Netlify détecte automatiquement Next.js et utilise son adaptateur OpenNext.

## Configuration Netlify

- Build command : `npm run build`
- Publish directory : `.next`
- Node : 22

Les variables suivantes doivent être configurées dans Netlify (elles ne doivent pas être mises dans `netlify.toml`) :

- `MONGODB_URI`
- `ADMIN_TOKEN`
- `ADMIN_JWT_SECRET`

## Important : fichiers uploadés

Les routes d'administration écrivent actuellement les photos dans `public/uploads`. Sur Netlify, le runtime des Functions est éphémère : ce dossier ne doit pas être considéré comme un stockage persistant.

Pour conserver les nouveaux uploads après les redéploiements, il faudra remplacer ce stockage local par un stockage persistant (par exemple Netlify Blobs ou un stockage objet externe). Les images déjà présentes dans `public/build/uploads` restent des fichiers statiques du dépôt et peuvent être servies par le site.
