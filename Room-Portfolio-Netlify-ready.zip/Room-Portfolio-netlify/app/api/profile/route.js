import { NextResponse } from 'next/server';
import dbConnect from '../../../lib/dbConnect';
import Profile from '../../../models/Profile';

export async function GET() {
  await dbConnect();
  let profile = await Profile.findOne();
  if (!profile) {
    profile = await Profile.create({
      description: '',
      linkedin: '',
      whatsapp: '',
      gmail: '',
      facebook: ''
    });
  }
  return NextResponse.json({ success: true, data: profile });
}

export async function PUT(req) {
  await dbConnect();
  const body = await req.json();
  let profile = await Profile.findOne();
  if (!profile) {
    profile = await Profile.create(body);
  } else {
    Object.assign(profile, body);
    await profile.save();
  }
  return NextResponse.json({ success: true, data: profile });
}
