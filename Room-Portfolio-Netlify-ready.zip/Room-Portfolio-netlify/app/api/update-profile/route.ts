import { NextRequest, NextResponse } from 'next/server';
import path from 'path';
import { promises as fs } from 'fs';

export async function PUT(request: NextRequest) {
  try {
    const formData = await request.formData();
    const updatedData: Record<string, any> = {};
    let allPhotos: string[] = [];
    for (const [key, value] of formData.entries()) {
      if (key === 'existingPhotos') {
        allPhotos = value ? JSON.parse(value as string) : [];
      }
    }
    const savedPhotos: string[] = [];
    const uploadDir = path.join(process.cwd(), 'public/uploads');
    try {
      await fs.access(uploadDir);
    } catch {
      await fs.mkdir(uploadDir, { recursive: true });
    }
    const processedKeys = new Set();
    for (const [key, value] of formData.entries()) {
      if (key === 'existingPhotos') continue;
      if (processedKeys.has(key)) continue;
      const allValues = formData.getAll(key);
      let isFileField = false;
      for (const v of allValues) {
        if (v instanceof File && v.size > 0) {
          isFileField = true;
          const bytes = await v.arrayBuffer();
          const buffer = Buffer.from(bytes);
          const timestamp = Date.now();
          const filename = `${timestamp}-${v.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
          const filepath = path.join(uploadDir, filename);
          await fs.writeFile(filepath, buffer);
          savedPhotos.push(`/uploads/${filename}`);
        }
      }
      if (!isFileField && allValues.length === 1) {
        updatedData[key] = allValues[0];
      } else if (!isFileField && allValues.length > 1) {
        updatedData[key] = allValues;
      }
      processedKeys.add(key);
    }
    updatedData.photos = [...allPhotos, ...savedPhotos];
    updatedData.updatedAt = new Date().toISOString();
    console.log('Données mises à jour:', updatedData);
    return NextResponse.json({ 
      success: true, 
      message: 'Profil mis à jour avec succès',
      data: updatedData 
    });
  } catch (error) {
    console.error('Erreur lors de la mise à jour:', error);
    return NextResponse.json(
      { success: false, message: 'Erreur serveur' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const userData = {
      firstName: "Jean",
      lastName: "Dupont", 
      email: "jean.dupont@example.com",
      bio: "Développeur passionné par les nouvelles technologies.",
      country: "fr",
      photos: [
        "/uploads/photo1.jpg",
        "/uploads/photo2.jpg"
      ]
    };
    return NextResponse.json({ 
      success: true, 
      data: userData 
    });
  } catch (error) {
    console.error('Erreur lors de la récupération:', error);
    return NextResponse.json(
      { success: false, message: 'Erreur serveur' },
      { status: 500 }
    );
  }
}
