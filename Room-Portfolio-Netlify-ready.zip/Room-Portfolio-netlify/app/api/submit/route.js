import { MongoClient, ObjectId } from "mongodb";

import fs from "fs";
import path from "path";

const uri = process.env.MONGODB_URI;
let client;
let clientPromise;
if (!uri) throw new Error('Veuillez définir la variable MONGODB_URI dans .env.local');
if (!global._mongoClientPromise) {
	client = new MongoClient(uri);
	global._mongoClientPromise = client.connect();
}
clientPromise = global._mongoClientPromise;

export async function POST(request) {
	try {
		const contentType = request.headers.get('content-type') || '';
		if (!contentType.includes('multipart/form-data')) {
			return new Response(JSON.stringify({ success: false, error: 'Content-Type must be multipart/form-data' }), {
				status: 400,
				headers: { 'Content-Type': 'application/json' },
			});
		}

		const formData = await request.formData();
		let fields = {};
		let photos = [];
		let existingPhotos = [];
		const entries = [...formData.entries()];
		for (const [key, value] of entries) {
			if (key === "photos" && value instanceof File) {
				console.log(`DEBUG - photo file detected: ${key}, name: ${value.name}`);
				const uploadsDir = path.join(process.cwd(), 'public/uploads');
				if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
				const ext = path.extname(value.name);
				const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`;
				const filePath = path.join(uploadsDir, fileName);
				const arrayBuffer = await value.arrayBuffer();
				fs.writeFileSync(filePath, Buffer.from(arrayBuffer));
				photos.push(`/uploads/${fileName}`);
			} else if (key === "existingPhotos") {
				try {
					existingPhotos = JSON.parse(value);
				} catch {
					existingPhotos = [];
				}
			} else {
				fields[key] = value;
			}
		}

		const allPhotos = Array.isArray(existingPhotos) ? [...existingPhotos, ...photos] : photos;

		const client = await clientPromise;
		const db = client.db();
		const collection = db.collection('form_submissions');
		let docToInsert = {};
		docToInsert.photos = allPhotos;
		Object.assign(docToInsert, fields);
		docToInsert.createdAt = new Date();
		if (fields._id) {
			if (/^[a-fA-F0-9]{24}$/.test(fields._id)) {
				docToInsert._id = new ObjectId(fields._id);
			} else {
				docToInsert._id = fields._id;
			}
		}
		console.log('DEBUG - docToInsert:', docToInsert);
		await collection.insertOne(docToInsert);
		return new Response(JSON.stringify({ success: true, photos }), {
			status: 200,
			headers: { 'Content-Type': 'application/json' },
		});
	} catch (error) {
		console.error('Erreur API /api/submit:', error);
		return new Response(JSON.stringify({ success: false, error: error.message, stack: error.stack }), {
			status: 500,
			headers: { 'Content-Type': 'application/json' },
		});
	}
}
