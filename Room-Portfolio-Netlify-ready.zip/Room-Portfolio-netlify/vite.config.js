export default {
  build: {
    // Keep existing files in public/build (portfolio assets/uploads) during deploy.
    emptyOutDir: false,
    outDir: 'public/build',
    rollupOptions: {
      input: './public/js/three.js',
      output: {
        entryFileNames: 'three.js',
      },
    },
  },
};
